const VersionInfo = () => {};

export default VersionInfo;
