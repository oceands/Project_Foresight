const AI = () => {
  //fill code here
};

export default AI;
